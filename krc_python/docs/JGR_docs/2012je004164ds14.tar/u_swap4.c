#include <stdio.h>
#include "isisdef.h"
#include "isistypes.h"
#include "u.h"
 

void u_swap4(INT4 nlongs, void *ibuf, void *obuf)
/***********************************************************************
*_Title u_swap4 Swap 2-byte words and then bytes in 32-bit long words
*_Args  Type    Name    I/O    Description
*_Parm  INT4    nlongs;  I     Number of 32 bit words to swap
*_Parm  void    *ibuf;   I     Input buffer containing long
*                              words to swap
*_Parm  void    *obuf;   O     Output buffer to place swapped
*                              long words

*_Descr u_swap4 swaps adjacent words and then adjacent bytes in each of
*       the words in a long word.  Note that the input buffer may also
*       be the output buffer (i.e., the results may be overlaid).

*_Hist  Sep 12 1991 Kris Becker, USGS, Flagstaff Original Version
*       Jul 31 1995 KJB - Ported to ANSI comliant multi-platform system
*       Nov 13 2003 KJB - Rewrote due to optimization bug in gcc 2.96
*                         (RedHat 7.3).  It needed it anyway!
*_End
************************************************************************/
{
  UINT4 *ip = (UINT4 *) ibuf;
  UINT4  *op = (UINT4 *) obuf;
  UINT1 *tbuf1, *tbuf2, tmp;
  INT4 i;
  INT4 nl = nlongs;


/***************************************************************
  Do the conversion
****************************************************************/
  for (i = 0 ; i < nl ; i++, ip++, op++) {
    tbuf1 = (UINT1 *) ip;
    tbuf2 = (UINT1 *) op;

    tmp = tbuf1[3];
    tbuf2[3] = tbuf1[0];
    tbuf2[0] = tmp;

    tmp = tbuf1[2];
    tbuf2[2] = tbuf1[1];
    tbuf2[1] = tmp;
  }

  return;
}
